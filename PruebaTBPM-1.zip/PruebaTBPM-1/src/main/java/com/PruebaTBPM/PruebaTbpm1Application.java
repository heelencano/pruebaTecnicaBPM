package com.PruebaTBPM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaTbpm1Application {

	public static void main(String[] args) {
		SpringApplication.run(PruebaTbpm1Application.class, args);
	}

}
